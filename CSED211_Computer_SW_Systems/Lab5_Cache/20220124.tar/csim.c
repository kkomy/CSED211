/* 20220124 Moonkyeom Kim*/

#include "cachelab.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <getopt.h>

/*hit, miss, eviction count variable*/
int hit_count = 0;
int miss_count = 0;
int eviction_count = 0;

/*cache structure decription*/
typedef struct{
    bool valid;
    int tag;
    int age;
} line;

typedef line* set;

typedef set* caches;

caches cache;
int s;
int E;
int b;
char* t;

int LRU = 0;
bool display = false;

int hit_miss(unsigned long long int tag, unsigned long long int set_index);
void eviction(unsigned long long int tag, unsigned long long int set_index);

int main(int argc, char *argv[])
{
        
    int opt;

    FILE* trace;
    char operation;
    unsigned long long int address;
    int size;
    unsigned long long int tag;
    unsigned long long int set_index;

    
    /*save command line argument*/
    while((opt = getopt(argc, argv, "hvs:E:b:t:")) != -1){
        switch(opt){
            case 'h':
            printf("Usage: ./csim-ref [-hv] -s <s> -E <E> -b <b> -t <tracefile>");
            break;
            case 'v':
            display = true;
            break;
            case 's':
            s = atoi(optarg);
            break;
            case 'E':
            E = atoi(optarg);
            break;
            case 'b':
            b = atoi(optarg);
            break;
            case 't':
            t = optarg;
            break;
        }

    }

    /*cache memory allocation*/
    cache = (set*)malloc(sizeof(set) * (1<<s));

    for(int i = 0; i < (1<<s); i++){

        cache[i] = (line*)malloc(sizeof(line) * (1<<E));

        for(int j=0;j<(1<<E);j++){

            cache[i][j].valid = false;
            cache[i][j].tag = 0;
            cache[i][j].age = 0;

        }

    }

    /*trace file reading*/
    trace = fopen(t,"r");

    while(fscanf(trace, " %c %llx, %d", &operation, &address, &size) != EOF){

        tag = address >> (s+b);
        set_index = (address >> b) & ((1<<s) - 1);

        if(display == true){
            printf("%c %llx, %d ", operation, address, size);
        }
        switch(operation){
            case 'L':
            case 'S':
            if(hit_miss(tag, set_index) == -1){
                eviction(tag, set_index);
            }
            break;

            case 'M':
            for(int i=0;i<2;i++){
                if(hit_miss(tag, set_index) == -1){
                    eviction(tag, set_index);
                }
            }
            break;
        }
        printf("\n");
    }

    for(int i=0;i<(1<<s);i++){ // deallocating
        free(cache[i]);
    }
    free(cache);

    fclose(trace); // file close

    
    
    printSummary(hit_count, miss_count, eviction_count);
    
    return 0;
}


int hit_miss(unsigned long long int tag, unsigned long long int set_index){

    /*hit process*/
    for(int i=0;i<E;i++){
        if(cache[set_index][i].tag == tag){ //check if the tag matches
            if(cache[set_index][i].valid == true){ //check the valid bit 

                hit_count++;
                if(display == true){
                    printf("hit ");
                }
                
                LRU++;
                cache[set_index][i].age = LRU;

                return 1; //if hit, quit function
            } 
        }
        
    }

    /*miss process*/
    miss_count++;

    if(display == true){
        printf("miss ");
    }

    return -1;
}

void eviction(unsigned long long int tag, unsigned long long int set_index){

    unsigned long long int oldst = cache[set_index][0].age;
    int change = 0;

    for(int i=0;i<E;i++){ // oldest block finding
        if(cache[set_index][i].age < oldst){
            oldst = cache[set_index][i].age; // renewal oldest block
        }
    }

    for(int i=0;i<E;i++){ // find line which have to evict
        if(cache[set_index][i].age == oldst){
            change = i;
        }
    }

    if(cache[set_index][change].valid == true){

        eviction_count++;
        if(display == true){
            printf("eviction ");
        }

    }

    /*replacing value*/
    cache[set_index][change].valid = true;
    cache[set_index][change].tag = tag;
    cache[set_index][change].age = LRU;

    return;

}
